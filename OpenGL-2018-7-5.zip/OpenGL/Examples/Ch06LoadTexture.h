#pragma once
#include "DrawInterface.h"
#include "vbm.h"


class Ch06LoadTexture :
	public IDrawInterface
{
public:
	Ch06LoadTexture();
	~Ch06LoadTexture();

	virtual void Init() override;

	virtual void Display() override;

private:
	GLuint base_prog;
	GLuint vao;

	GLuint quad_vbo;

	GLuint tex;
};

