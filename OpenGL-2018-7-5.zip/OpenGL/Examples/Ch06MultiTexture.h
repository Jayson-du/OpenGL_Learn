#pragma once
#include "DrawInterface.h"
#include "vbm.h"

class Ch06MultiTexture :
	public IDrawInterface
{
public:
	Ch06MultiTexture();
	~Ch06MultiTexture();

	virtual void Init() override;

	virtual void Display() override;
private:
	GLuint base_prog;
	GLuint vao;

	GLuint quad_vbo;

	GLuint tex1;
	GLuint tex2;

	GLint  time_loc;
};

