#pragma once
#include "DrawInterface.h"
class Ch06PointsSprites :public IDrawInterface
{
public:
	Ch06PointsSprites();
	~Ch06PointsSprites();

	void Init() override;
	void Display() override;
	void OnKeyboard(unsigned char key, int x, int y) override;
private:
	GLuint render_prog;
	GLuint vao[1];
	GLuint vbo[1];
	GLuint sprite_texture;

	GLint render_model_matrix_loc;
	GLint render_projection_matrix_loc;
};

