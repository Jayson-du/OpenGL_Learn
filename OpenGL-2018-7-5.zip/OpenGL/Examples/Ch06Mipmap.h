#pragma once
#include "DrawInterface.h"
#include "vbm.h"

class Ch06Mipmap :
	public IDrawInterface
{
public:
	Ch06Mipmap();
	~Ch06Mipmap();

	virtual void Init() override;

	virtual void Display() override;

	virtual void OnKeyboard(unsigned char key, int x, int y) override;
private:
	GLuint mipmap_prog;
	GLuint vao;

	GLuint cube_vbo;
	GLuint cube_element_buffer;

	GLuint tex;
	GLint skybox_rotate_loc;

	GLint object_mat_mvp_loc;
	GLint object_mat_mv_loc;

	VBObject object;
};

