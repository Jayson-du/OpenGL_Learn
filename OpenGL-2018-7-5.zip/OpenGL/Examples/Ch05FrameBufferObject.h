#pragma once
#include "DrawInterface.h"
#include "vbm.h"

// С��ͼ��ʵ��ԭ��
class Ch05FrameBufferObject : public IDrawInterface
{
public:
	Ch05FrameBufferObject();
	~Ch05FrameBufferObject();

	virtual void Init() override;
	virtual void Display() override;
	
	void InitInstance();
	void DrawInstance();
private:
	enum {Color, Depth,NumRenderBuffers};
	GLuint FrameBuffer;
	GLuint RenderBuffer[NumRenderBuffers];

	//////////////////////////////////////////////////////////////////////////
	GLuint color_buffer;
	GLuint model_matrix_buffer;
	GLuint color_tbo;
	GLuint model_matrix_tbo;
	GLuint render_prog;

	GLint view_matrix_loc;
	GLint projection_matrix_loc;

	VBObject object;
};

