#pragma once
#include "DrawInterface.h"
class Ch03Restart : public IDrawInterface
{
public:
	Ch03Restart();
	~Ch03Restart();
	void Init() override;
	void Display() override;
private:
	GLuint render_prog;
	GLuint vao[1];
	GLuint vbo[1];
	GLuint ebo[1];

	GLint render_model_matrix_loc;
	GLint render_projection_matrix_loc;
};

