#pragma once
#include "DrawInterface.h"
#include "vbm.h"
class Ch06TextureWrapping :
	public IDrawInterface
{
public:
	Ch06TextureWrapping();
	~Ch06TextureWrapping();

	virtual void Init() override;

	virtual void Display() override;

private:
	GLuint base_prog;
	GLuint vao;

	GLuint quad_vbo;

	GLuint tex;
};

