#pragma once
#include "DrawInterface.h"
#include "vbm.h"

class Ch06StaticTexture :
	public IDrawInterface
{
public:
	Ch06StaticTexture();
	~Ch06StaticTexture();

	virtual void Init() override;

	virtual void Display() override;

private:
	GLuint base_prog;
	GLuint vao;

	GLuint quad_vbo;

	GLuint tex;
};

