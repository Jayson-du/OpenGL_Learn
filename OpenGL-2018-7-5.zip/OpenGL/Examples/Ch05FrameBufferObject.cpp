#include "Ch05FrameBufferObject.h"

#define INSTANCE_COUNT 200

Ch05FrameBufferObject::Ch05FrameBufferObject()
{
}


Ch05FrameBufferObject::~Ch05FrameBufferObject()
{
}

void Ch05FrameBufferObject::Init()
{
	// ����֡����
	glGenFramebuffers(1, &FrameBuffer);
	glBindFramebuffer(GL_DRAW_FRAMEBUFFER, FrameBuffer);

	// ������Ⱦ���棬һ����ɫ��Ⱦ���棬һ�������Ⱦ����
	glGenRenderbuffers(NumRenderBuffers, RenderBuffer);
	glBindRenderbuffer(GL_RENDERBUFFER, RenderBuffer[Color]);
	glRenderbufferStorage(GL_RENDERBUFFER, GL_RGBA, 256, 256);
	glBindRenderbuffer(GL_RENDERBUFFER, RenderBuffer[Depth]);
	glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT24, 256, 256);

	//����������Ⱦ����������뻺���Attachment��
	glFramebufferRenderbuffer(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_RENDERBUFFER, RenderBuffer[Color]);
	glFramebufferRenderbuffer(GL_DRAW_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_RENDERBUFFER, RenderBuffer[Depth]);

	// ��ʼ��Ϊ�˻���framebuffer�ϵĶ���
	InitInstance();

	// Setup
	glEnable(GL_CULL_FACE);
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
}

void Ch05FrameBufferObject::Display()
{
	glBindFramebuffer(GL_DRAW_FRAMEBUFFER, FrameBuffer);
	glViewport(0, 0, 256, 256);
	glClearColor(0.0, 0.0, 0.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	DrawInstance();

	//����Ⱦ�����ȡ������Ⱦ������
	glBindFramebuffer(GL_READ_FRAMEBUFFER, FrameBuffer);
	glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
	glBindVertexArray(0);
	glViewport(0, 0, current_width, current_height);
	glClearColor(0.0, 0.0, 1.0, 1.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glBlitFramebuffer(0, 0, 255, 255, current_width -255, 0, current_width, 255, GL_COLOR_BUFFER_BIT, GL_NEAREST);
	glBlitFramebuffer(0, 0, 255, 255, 0, 0, 255, 255, GL_COLOR_BUFFER_BIT, GL_NEAREST);//GL_DEPTH_BUFFER_BIT
}

void Ch05FrameBufferObject::InitInstance()
{

	//////////////////////////////////////////////////////////////////////////
	int n;
	ShaderInfo instance_info[] = {
		{GL_VERTEX_SHADER,"shaders/03/instance3.vs.glsl"},
		{GL_FRAGMENT_SHADER,"shaders/03/instance3.fs.glsl"},
		{GL_NONE,nullptr}
	};
	render_prog = LoadShaders(instance_info);
	glUseProgram(render_prog);

	// Get the location of the projetion_matrix uniform
	view_matrix_loc = glGetUniformLocation(render_prog, "view_matrix");
	projection_matrix_loc = glGetUniformLocation(render_prog, "projection_matrix");

	// Set up the TBO samplers
	GLuint color_tbo_loc = glGetUniformLocation(render_prog, "color_tbo");
	GLuint model_matrix_tbo_loc = glGetUniformLocation(render_prog, "model_matrix_tbo");

	// Set them to the right texture unit indices
	glUniform1i(color_tbo_loc, 0);
	glUniform1i(model_matrix_tbo_loc, 1);

	// Load the object
	object.LoadFromVBM("media/armadillo_low.vbm", 0, 1, 2);

	glGenTextures(1, &color_tbo);
	glBindTexture(GL_TEXTURE_BUFFER, color_tbo);

	// Generate the colors of the objects
	vec4 colors[INSTANCE_COUNT];

	for (n = 0; n < INSTANCE_COUNT; n++)
	{
		float a = float(n) / 4.0f;
		float b = float(n) / 5.0f;
		float c = float(n) / 6.0f;

		colors[n][0] = 0.5f + 0.25f * (sinf(a + 1.0f) + 1.0f);
		colors[n][1] = 0.5f + 0.25f * (sinf(b + 2.0f) + 1.0f);
		colors[n][2] = 0.5f + 0.25f * (sinf(c + 3.0f) + 1.0f);
		colors[n][3] = 1.0f;
	}

	// Create the buffer, initialize it and attach it to the buffer texture
	glGenBuffers(1, &color_buffer);
	glBindBuffer(GL_TEXTURE_BUFFER, color_buffer);
	glBufferData(GL_TEXTURE_BUFFER, sizeof(colors), colors, GL_STATIC_DRAW);
	glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, color_buffer);

	// Now do the same thing with a TBO for the model matrices. The buffer object
	// (model_matrix_buffer) has been created and sized to store one mat4 per-
	// instance.
	glGenTextures(1, &model_matrix_tbo);
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_BUFFER, model_matrix_tbo);
	glGenBuffers(1, &model_matrix_buffer);
	glBindBuffer(GL_TEXTURE_BUFFER, model_matrix_buffer);
	glBufferData(GL_TEXTURE_BUFFER, INSTANCE_COUNT * sizeof(mat4), NULL, GL_DYNAMIC_DRAW);
	glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, model_matrix_buffer);
	glActiveTexture(GL_TEXTURE0);
}

void Ch05FrameBufferObject::DrawInstance()
{
	float t = float(GetTickCount() & 0x3FFF) / float(0x3FFF);
	static float q = 0.0f;
	static const vec3 X(1.0f, 0.0f, 0.0f);
	static const vec3 Y(0.0f, 1.0f, 0.0f);
	static const vec3 Z(0.0f, 0.0f, 1.0f);
	int n;

	// Set model matrices for each instance
	mat4 matrices[INSTANCE_COUNT];

	for (n = 0; n < INSTANCE_COUNT; n++)
	{
		float a = 50.0f * float(n) / 4.0f;
		float b = 50.0f * float(n) / 5.0f;
		float c = 50.0f * float(n) / 6.0f;

		matrices[n] = rotate(a + t * 360.0f, 1.0f, 0.0f, 0.0f) *
			rotate(b + t * 360.0f, 0.0f, 1.0f, 0.0f) *
			rotate(c + t * 360.0f, 0.0f, 0.0f, 1.0f) *
			translate(10.0f + a, 40.0f + b, 50.0f + c);
	}

	// Bind the weight VBO and change its data
	glBindBuffer(GL_TEXTURE_BUFFER, model_matrix_buffer);
	glBufferData(GL_TEXTURE_BUFFER, sizeof(matrices), matrices, GL_DYNAMIC_DRAW);

	// Clear
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// Activate instancing program
	glUseProgram(render_prog);

	// Set up the view and projection matrices
	mat4 view_matrix(translate(0.0f, 0.0f, -1500.0f) * rotate(t * 360.0f * 2.0f, 0.0f, 1.0f, 0.0f));
	mat4 projection_matrix(frustum(-1.0f, 1.0f, -aspect, aspect, 1.0f, 5000.0f));

	glUniformMatrix4fv(view_matrix_loc, 1, GL_FALSE, view_matrix);
	glUniformMatrix4fv(projection_matrix_loc, 1, GL_FALSE, projection_matrix);

	// Render INSTANCE_COUNT objects
	object.Render(0, INSTANCE_COUNT);
}
