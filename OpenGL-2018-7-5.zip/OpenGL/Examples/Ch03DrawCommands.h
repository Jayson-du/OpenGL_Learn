#pragma once
#include "DrawInterface.h"
class Ch03DrawCommands : public IDrawInterface
{
public:
	Ch03DrawCommands();
	~Ch03DrawCommands();
	void Init() override;

	void Display() override;
private:
	// Member variables
	float aspect;
	GLuint render_prog;
	GLuint vao[1];
	GLuint vbo[1];
	GLuint ebo[1];

	GLint render_model_matrix_loc;
	GLint render_projection_matrix_loc;
};

