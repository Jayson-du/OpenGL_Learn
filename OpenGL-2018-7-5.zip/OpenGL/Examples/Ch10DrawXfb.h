#pragma once
#include "DrawInterface.h"
#include "vbm.h"
class Ch10DrawXfb :
	public IDrawInterface
{
public:
	Ch10DrawXfb();
	~Ch10DrawXfb();

	virtual void Init() override;

	virtual void Display() override;
private:
	GLuint sort_prog;
	GLuint render_prog;
	GLuint vao[2];
	GLuint vbo[2];
	GLuint xfb;
	VBObject object;

	GLint model_matrix_pos;
	GLint projection_matrix_pos;
	GLint model_interval;
};

