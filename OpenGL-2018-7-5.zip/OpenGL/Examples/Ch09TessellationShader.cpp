#include "Ch09TessellationShader.h"
#include "Teapot.h"

using namespace vmath;
using namespace std;

Ch09TessellationShader::Ch09TessellationShader() :
	Inner(1.0f),
	Outer(1.0f)
{
}


Ch09TessellationShader::~Ch09TessellationShader()
{
}

void Ch09TessellationShader::Init()
{
	// Create a vertex array object
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	// Create and initialize a buffer object

	glGenBuffers(NumVertexBuffers, buffers);
	glBindBuffer(GL_ARRAY_BUFFER, buffers[ArrayBuffer]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(TeapotVertices),
		TeapotVertices, GL_STATIC_DRAW);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, buffers[ElementBuffer]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(TeapotIndices),
		TeapotIndices, GL_STATIC_DRAW);

	// Load shaders and use the resulting shader program
	ShaderInfo  shaders[] = {
		{ GL_VERTEX_SHADER,          "shaders/teapot/teapot.vert.glsl" },
		{ GL_TESS_CONTROL_SHADER,    "shaders/teapot/teapot.cont.glsl" },
		{ GL_TESS_EVALUATION_SHADER, "shaders/teapot/teapot.eval.glsl" },
		{ GL_FRAGMENT_SHADER,        "shaders/teapot/teapot.frag.glsl" },
		{ GL_NONE, NULL }
	};

	program = LoadShaders(shaders);
	glUseProgram(program);

	// set up vertex arrays
	GLuint vPosition = glGetAttribLocation(program, "vPosition");
	glEnableVertexAttribArray(vPosition);
	glVertexAttribPointer(vPosition, 3, GL_DOUBLE, GL_FALSE, 0, BUFFER_OFFSET(0));

	PLoc = glGetUniformLocation(program, "P");
	InnerLoc = glGetUniformLocation(program, "Inner");
	OuterLoc = glGetUniformLocation(program, "Outer");

	glUniform1f(InnerLoc, Inner);
	glUniform1f(OuterLoc, Outer);

	//mat4  modelview = vmath::translate(-0.2625f, -1.575f, -1.0f);
	//modelview *= vmath::translate(0.0f, 0.0f, -7.5f);
	mat4 modelview = /*translate(-0.2625f, -1.575f, 100.0f) **/ scale(0.3f);
	glUniformMatrix4fv(glGetUniformLocation(program, "MV"), 1, GL_TRUE, modelview);

	glPatchParameteri(GL_PATCH_VERTICES, NumTeapotVerticesPerPatch);

	glClearColor(0.0, 0.0, 0.0, 1.0);
}

void Ch09TessellationShader::Display()
{
	static const unsigned int start_time = GetTickCount();
	float t = float((GetTickCount() - start_time)) / float(0x3FFF);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	GLfloat  aspect = GLfloat(current_width) / current_height;
	mat4  projection = perspective(90.f, aspect, 1, -10000) * rotate(sinf(t)* 180.f, vec3(0.0f, 1.0f, 0.0f));
	//mat4  projection = frustum( -3, 3, -3, 3, 5, -1000 );
	glUniformMatrix4fv(PLoc, 1, GL_TRUE, projection);
	glDrawElements(GL_PATCHES, NumTeapotVertices, GL_UNSIGNED_INT, BUFFER_OFFSET(0));
}

void Ch09TessellationShader::OnKeyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case 'q': case 'Q': case 033 /* Escape key */:
		exit(EXIT_SUCCESS);
		break;

	case 'i':
		Inner--;
		if (Inner < 1.0)  Inner = 1.0;
		glUniform1f(InnerLoc, Inner);
		break;

	case 'I':
		Inner++;
		if (Inner > 64)  Inner = 64.0;
		glUniform1f(InnerLoc, Inner);
		break;

	case 'o':
		Outer--;
		if (Outer < 1.0)  Outer = 1.0;
		glUniform1f(OuterLoc, Outer);
		break;

	case 'O':
		Outer++;
		if (Outer > 64)  Outer = 64.0;
		glUniform1f(OuterLoc, Outer);
		break;

	case 'r':
		Inner = 1.0;
		Outer = 1.0;
		glUniform1f(InnerLoc, Inner);
		glUniform1f(OuterLoc, Outer);
		break;

	case 'm': {
		GLenum mode[3] = { GL_FILL ,GL_LINE,GL_POINT};
		static int pmodel = 0;
		pmodel = (pmodel + 1) % 3;
		glPolygonMode(GL_FRONT_AND_BACK, mode[pmodel]);
	} break;
	case 'p': {
		glPolygonMode(GL_FRONT_AND_BACK, GL_POINT);
	} break;
	}

}
