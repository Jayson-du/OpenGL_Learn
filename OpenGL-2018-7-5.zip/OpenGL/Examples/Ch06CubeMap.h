#pragma once
#include "DrawInterface.h"
#include "vbm.h"
class Ch06CubeMap :
	public IDrawInterface
{
public:
	Ch06CubeMap();
	~Ch06CubeMap();

	virtual void Init() override;

	virtual void Display() override;

protected:
	GLuint skybox_prog;
	GLuint object_prog;
	GLuint vao;

	GLuint cube_vbo;
	GLuint cube_element_buffer;

	GLuint tex;
	GLint skybox_rotate_loc;

	GLint object_mat_mvp_loc;
	GLint object_mat_mv_loc;

	VBObject object;
};

