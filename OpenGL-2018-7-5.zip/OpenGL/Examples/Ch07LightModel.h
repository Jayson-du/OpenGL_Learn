#pragma once
#include "DrawInterface.h"
#include "vbm.h"

class Ch07LightModel : public IDrawInterface
{
public:
	Ch07LightModel();
	~Ch07LightModel();

	virtual void Init() override;

	virtual void Display() override;

public:
	GLuint  output_image;
	GLuint  render_prog;

	GLint   mv_mat_loc;
	GLint   prj_mat_loc;
	GLint   col_amb_loc;
	GLint   col_diff_loc;
	GLint   col_spec_loc;

	VBObject    object;
};

