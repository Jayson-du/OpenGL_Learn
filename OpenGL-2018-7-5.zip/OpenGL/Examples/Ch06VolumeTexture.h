#pragma once
#include "DrawInterface.h"
#include "vbm.h"


class Ch06VolumeTexture : public IDrawInterface
{
public:
	Ch06VolumeTexture();
	~Ch06VolumeTexture();

	virtual void Init() override;

	virtual void Display() override;

private:
	float aspect;
	GLuint base_prog;
	GLuint vao;

	GLuint quad_vbo;

	GLuint tex;
	GLint tc_rotate_loc;
};

