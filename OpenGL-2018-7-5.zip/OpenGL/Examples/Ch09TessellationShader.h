#pragma once
#include "DrawInterface.h"
class Ch09TessellationShader :
	public IDrawInterface
{
public:
	Ch09TessellationShader();
	~Ch09TessellationShader();

	virtual void Init() override;
	virtual void Display() override;

	virtual void OnKeyboard(unsigned char key, int x, int y) override;

private:
	GLuint  PLoc;  // Projection matrix
	GLuint  InnerLoc;  // Inner tessellation paramter
	GLuint  OuterLoc;  // Outer tessellation paramter
	GLuint vao;
	GLuint program;

	GLfloat  Inner;
	GLfloat  Outer;

	enum { ArrayBuffer, ElementBuffer, NumVertexBuffers };
	GLuint buffers[NumVertexBuffers];
};

