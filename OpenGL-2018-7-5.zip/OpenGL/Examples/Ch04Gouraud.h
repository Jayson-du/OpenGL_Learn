#pragma once
#include "DrawInterface.h"
class Ch04Gouraud : public IDrawInterface
{
public:
	Ch04Gouraud();
	~Ch04Gouraud();

	void Init() override;

	void Display() override;

	void OnKeyboard(unsigned char key, int x, int y) override;
private:
	enum VAO_IDs { Triangles, NumVAOs };
	enum Buffer_IDs { ArrayBuffer, NumBuffers };
	enum Attrib_IDs { vPosition = 0, vColor = 1 };

	GLuint  VAOs[NumVAOs];
	GLuint  Buffers[NumBuffers];

#define   NumVertices   6
};

