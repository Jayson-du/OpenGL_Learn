#pragma once
#include "DrawInterface.h"
#include "vbm.h"
class Ch10Fur :
	public IDrawInterface
{
public:
	Ch10Fur();
	~Ch10Fur();

	virtual void Init() override;

	virtual void Display() override;

private:
	GLuint base_prog;
	GLuint fur_prog;
	GLuint fur_texture;
	VBObject object;

	GLint fur_model_matrix_pos;
	GLint fur_projection_matrix_pos;
	GLint base_model_matrix_pos;
	GLint base_projection_matrix_pos;
	GLint fur_layers;
};

