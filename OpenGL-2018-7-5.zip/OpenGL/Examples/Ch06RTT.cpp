#include "Ch06RTT.h"
#include "stdio.h"
#define INSTANCE_COUNT 200

Ch06RTT::Ch06RTT() :TexWidth(512), TexHeight(512), FrameBuffer(0)
{
}


Ch06RTT::~Ch06RTT()
{
}

void Ch06RTT::Init()
{
	InitRttContent();
	InitCube();
	glClearColor(0, 0, 0, 0);
	glEnable(GL_DEPTH_TEST);
}

void Ch06RTT::Display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_CULL_FACE); // ��������
	glCullFace(GL_BACK);	// �õ�����
	// ���Ȼ���
	DisplayRttContent();
	DisplayCube();
	//֡������ʾ�ڴ������½�/////////////////////////////////////////////////////////////////
	glBindFramebuffer(GL_READ_FRAMEBUFFER, FrameBuffer);
	glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
	glBlitFramebuffer(0, 0, TexWidth, TexHeight, current_width - 200, 0, current_width, 200, GL_COLOR_BUFFER_BIT, GL_NEAREST);
}

void Ch06RTT::InitCube()
{
	//���ɶ����������
	glGenVertexArrays(1, &CubeVBO);
	glBindVertexArray(CubeVBO);

	GLuint cubBuffer;
	CubeVertices = new VertexData[36]{

	// ����
	{ { -0.5, -0.5, -0.5 },{ 0.00f, 0.00f } },
	{ { -0.5, -0.5,  0.5 },{ 0.00f, 1.00f } },
	{ { -0.5,  0.5,  0.5 },{ 1.00f, 1.0f } }, 
	{ { -0.5,  0.5,  0.5 },{ 1.00f, 1.0f } } ,
	{ { -0.5,  0.5, -0.5 },{ 1.0f, 0.0f } },  
	{ { -0.5, -0.5, -0.5 },{ 0.00f, 0.00f } },
	//��
	{ { -0.5,  0.5,  0.5 },{ 0.00f, 0.0f } }, 
	{ { 0.5,   0.5,  0.5 },{ 0.0f, 1.0f } },  
	{ { 0.5,  0.5, -0.5 },{ 1.0f, 1.0f } },  
	{ { 0.5,  0.5, -0.5 },{ 1.0f, 1.0f } },  
	{ { -0.5,  0.5, -0.5 },{ 1.00f, 0.0f } }, 
	{ { -0.5,  0.5,  0.5 },{ 0.00f, 0.0f } }, 
	//��
	{ { -0.5, -0.5,  0.5 },{ 0.00f, 0.00f } },
	{ {-0.5, -0.5, -0.5},{ 0.00f, 1.00f } },  
	{ { 0.5, -0.5, -0.5 },{ 1.0f, 1.00f } },  
	{ { 0.5, -0.5, -0.5 },{ 1.0f, 1.00f } },  
	{ { 0.5,  -0.5,  0.5 },{ 0.0f, 1.00f } }, 
	{ { -0.5, -0.5,  0.5 },{ 0.00f, 0.00f } },
	// ��
	{ { 0.5,   0.5,  0.5 },{ 1.0f, 0.0f } },  
	{ { 0.5,  -0.5,  0.5 },{ 0.0f, 0.00f } }, 
	{ { 0.5, -0.5, -0.5 },{ 0.0f, 1.00f } },  
	{ { 0.5, -0.5, -0.5 },{ 0.0f, 1.00f } },  
	{ { 0.5,  0.5, -0.5 },{ 1.0f, 1.0f } },  
	{ { 0.5,   0.5,  0.5 },{ 1.0f, 0.0f } },  
	// ��
	{ { 0.5,   0.5,  0.5 },{ 1.0f, 1.0f } },  
	{ { -0.5,  0.5,  0.5 },{ 0.00f, 1.0f } }, 
	{ { -0.5, -0.5,  0.5 },{ 0.00f, 0.00f } },
	{ { -0.5, -0.5,  0.5 },{ 0.00f, 0.00f } },
	{ { 0.5,  -0.5,  0.5 },{ 1.0f, 0.00f } }, 
	{ { 0.5,   0.5,  0.5 },{ 1.0f, 1.0f } },  
	// ����
	{ { 0.5, -0.5, -0.5 },{ 1.0f, 0.00f } },  
	{ { -0.5, -0.5, -0.5 },{ 0.00f, 0.00f } },
	{ { -0.5,  0.5, -0.5 },{ 0.00f, 1.0f } }, 
	{ { -0.5,  0.5, -0.5 },{ 0.00f, 1.0f } }, 
	{ { 0.5,  0.5, -0.5 },{ 1.0f, 1.0f } },  
	{ { 0.5, -0.5, -0.5 },{ 1.0f, 0.00f } },  
	};

	// ���䶥�㻺��
	glGenBuffers(1, &cubBuffer);
	glBindBuffer(GL_ARRAY_BUFFER, cubBuffer);
	glBufferData(GL_ARRAY_BUFFER, sizeof(VertexData) * 36, CubeVertices, GL_STATIC_DRAW);

	// ����shader����
	ShaderInfo shaders[] = {
	{ GL_VERTEX_SHADER, "shaders/06/Rtt-cube.vs.glsl" },
	{ GL_FRAGMENT_SHADER, "shaders/06/Rtt-cube.fs.glsl" },
	{ GL_NONE, NULL }
	};
	CubeShaderHandle = LoadShaders(shaders);
	glUseProgram(CubeShaderHandle);
	ModelMatrix = glGetUniformLocation(CubeShaderHandle, "modelMatrix");

	// ���ö������ԣ�����shader�е�����
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(VertexData), BUFFER_OFFSET(0));
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(VertexData), BUFFER_OFFSET(sizeof(GLfloat)*3));
	glEnableVertexAttribArray(0);
	glEnableVertexAttribArray(1);
}

void Ch06RTT::DisplayCube()
{
	glViewport(0, 0, current_width, current_height);
	glClearColor(0, 0, 0, 1);
	glEnable(GL_TEXTURE_2D);

	static int  t = 0;
	++t %= 100000;
	float rad = t*0.01 / 180.f*3.14;
	float s = sin(rad);
	float cs = cos(rad);
	mat4 mm =
		rotate( cs* 360.0f, 1.0f, 0.0f, 0.0f)*
		rotate(s * 360.0f, 0.0f, 1.0f, 0.0f);
	glUseProgram(CubeShaderHandle);
	glBindVertexArray(CubeVBO);
	glBindTexture(GL_TEXTURE_2D, Texture);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);//���ԷŴ�
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);//������С
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);//s�������ģʽ
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);//t�������ģʽ

	glUniformMatrix4fv(ModelMatrix, 1, GL_FALSE, mm);

	glDrawArrays(GL_TRIANGLES, 0, 36);
}

void Ch06RTT::InitRttContent()
{
	// ���������ռ�
	glGenTextures(1, &Texture);
	glBindTexture(GL_TEXTURE_2D, Texture);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, TexWidth, TexHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL);
	// ����֡���棬��������������֡���渽��
	glGenFramebuffers(1, &FrameBuffer);
	glBindFramebuffer(GL_DRAW_FRAMEBUFFER, FrameBuffer);
	glFramebufferTexture2D(GL_DRAW_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, Texture, 0);
	// ����ģ��
	//////////////////////////////////////////////////////////////////////////
	int n;
	ShaderInfo instance_info[] = {
		{ GL_VERTEX_SHADER,"shaders/03/instance3.vs.glsl" },
		{ GL_FRAGMENT_SHADER,"shaders/03/instance3.fs.glsl" },
		{ GL_NONE,nullptr }
	};
	render_prog = LoadShaders(instance_info);
	glUseProgram(render_prog);

	// Get the location of the projetion_matrix uniform
	view_matrix_loc = glGetUniformLocation(render_prog, "view_matrix");
	projection_matrix_loc = glGetUniformLocation(render_prog, "projection_matrix");

	// Set up the TBO samplers
	GLuint color_tbo_loc = glGetUniformLocation(render_prog, "color_tbo");
	GLuint model_matrix_tbo_loc = glGetUniformLocation(render_prog, "model_matrix_tbo");

	// Set them to the right texture unit indices
	glUniform1i(color_tbo_loc, 0);
	glUniform1i(model_matrix_tbo_loc, 1);


	object.LoadFromVBM("media/armadillo_low.vbm", 0, 1, 2);

	glGenTextures(1, &color_tbo);
	glBindTexture(GL_TEXTURE_BUFFER, color_tbo);

	vec4 colors[INSTANCE_COUNT];
	for (n = 0; n < INSTANCE_COUNT; n++)
	{
		float a = float(n) / 4.0f;
		float b = float(n) / 5.0f;
		float c = float(n) / 6.0f;

		colors[n][0] = 0.5f + 0.25f * (sinf(a + 1.0f) + 1.0f);
		colors[n][1] = 0.5f + 0.25f * (sinf(b + 2.0f) + 1.0f);
		colors[n][2] = 0.5f + 0.25f * (sinf(c + 3.0f) + 1.0f);
		colors[n][3] = 1.0f;
	}

	glGenBuffers(1, &color_buffer);
	glBindBuffer(GL_TEXTURE_BUFFER, color_buffer);
	glBufferData(GL_TEXTURE_BUFFER, sizeof(colors), colors, GL_STATIC_DRAW);
	glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, color_buffer);

	glGenTextures(1, &model_matrix_tbo);
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_BUFFER, model_matrix_tbo);
	glGenBuffers(1, &model_matrix_buffer);
	glBindBuffer(GL_TEXTURE_BUFFER, model_matrix_buffer);
	glBufferData(GL_TEXTURE_BUFFER, INSTANCE_COUNT * sizeof(mat4), NULL, GL_DYNAMIC_DRAW);
	glTexBuffer(GL_TEXTURE_BUFFER, GL_RGBA32F, model_matrix_buffer);

	glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
}

void Ch06RTT::DisplayRttContent()
{
	glBindFramebuffer(GL_DRAW_FRAMEBUFFER, FrameBuffer);
	glViewport(0, 0, TexWidth, TexHeight);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glGenerateMipmap(GL_TEXTURE_2D);
	//...
	float t = float(GetTickCount() & 0x3FFF) / float(0x3FFF);
	static float q = 0.0f;
	static const vec3 X(1.0f, 0.0f, 0.0f);
	static const vec3 Y(0.0f, 1.0f, 0.0f);
	static const vec3 Z(0.0f, 0.0f, 1.0f);
	int n;

	// Set model matrices for each instance
	mat4 matrices[INSTANCE_COUNT];

	for (n = 0; n < INSTANCE_COUNT; n++)
	{
		float a = 50.0f * float(n) / 4.0f;
		float b = 50.0f * float(n) / 5.0f;
		float c = 50.0f * float(n) / 6.0f;

		matrices[n] = rotate(a + t * 360.0f, 1.0f, 0.0f, 0.0f) *
			rotate(b + t * 360.0f, 0.0f, 1.0f, 0.0f) *
			rotate(c + t * 360.0f, 0.0f, 0.0f, 1.0f) *
			translate(10.0f + a, 40.0f + b, 50.0f + c);
	}

	// Bind the weight VBO and change its data
	glActiveTexture(GL_TEXTURE0);
	glBindBuffer(GL_TEXTURE_BUFFER, model_matrix_buffer);
	glBufferData(GL_TEXTURE_BUFFER, sizeof(matrices), matrices, GL_DYNAMIC_DRAW);

	// Activate instancing program
	glUseProgram(render_prog);

	// Set up the view and projection matrices
	mat4 view_matrix(translate(0.0f, 0.0f, -1500.0f) * rotate(t * 360.0f * 2.0f, 0.0f, 1.0f, 0.0f));
	mat4 projection_matrix(frustum(-1.0f, 1.0f, -aspect, aspect, 1.0f, 5000.0f));

	glUniformMatrix4fv(view_matrix_loc, 1, GL_FALSE, view_matrix);
	glUniformMatrix4fv(projection_matrix_loc, 1, GL_FALSE, projection_matrix);

	// Render INSTANCE_COUNT objects
	glClearColor(1, 1, 0, 0);
	object.Render(0, INSTANCE_COUNT);

	glBindFramebuffer(GL_DRAW_FRAMEBUFFER, 0);
}
