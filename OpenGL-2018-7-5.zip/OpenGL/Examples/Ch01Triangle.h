#pragma once
#include "DrawInterface.h"
class Ch01Triangle :
	public IDrawInterface
{
public:
	Ch01Triangle();

public: // interface
	void Init() override;
	void Display() override;

private:
	enum VAO_IDs { Triangles, NumVAOs };
	enum Buffer_IDs { ArrayBuffer, NumBuffers };
	enum Attrib_IDs { vPosition = 0 };
	GLuint VAOs[NumVAOs];
	GLuint Buffers[NumBuffers];
#define NumVertices 6
};

