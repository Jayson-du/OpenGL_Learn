#pragma once
#include "DrawInterface.h"
#include "vbm.h"

class Ch06MipFilters : public IDrawInterface
{
public:
	Ch06MipFilters();
	~Ch06MipFilters();

	virtual void Init() override;

	virtual void Display() override;
private:
	GLuint mipmap_prog;
	GLuint vao;

	GLuint cube_vbo;
	GLuint cube_element_buffer;

	GLuint tex;
	GLint skybox_rotate_loc;

	GLint object_mat_mvp_loc;
	GLint object_mat_mv_loc;

	VBObject object;
};

