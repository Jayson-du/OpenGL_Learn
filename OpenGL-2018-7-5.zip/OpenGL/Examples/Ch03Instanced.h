#pragma once
#include "DrawInterface.h"
#include "vbm.h"
class Ch03Instanced : public IDrawInterface
{
public:
	Ch03Instanced();
	~Ch03Instanced();

	void Init() override;

	void Display() override;
private:
	GLuint color_buffer;
	GLuint model_matrix_buffer;
	GLuint color_tbo;
	GLuint model_matrix_tbo;
	GLuint render_prog;

	GLint view_matrix_loc;
	GLint projection_matrix_loc;

	VBObject object;
};

