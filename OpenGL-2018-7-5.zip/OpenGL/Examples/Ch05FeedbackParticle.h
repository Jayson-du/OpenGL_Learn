#pragma once
#include "DrawInterface.h"
#include "vbm.h"
class Ch05FeedbackParticle : public IDrawInterface
{
public:
	Ch05FeedbackParticle();
	~Ch05FeedbackParticle();

	void Init() override;

	void Display() override;
private:
	GLuint update_prog;
	GLuint vao[2];
	GLuint vbo[2];
	GLuint xfb;

	GLuint render_prog;
	GLuint geometry_vbo;
	GLuint render_vao;
	GLint render_model_matrix_loc;
	GLint render_projection_matrix_loc;

	GLuint geometry_tex;

	GLuint geometry_xfb;
	GLuint particle_xfb;

	GLint model_matrix_loc;
	GLint projection_matrix_loc;
	GLint triangle_count_loc;
	GLint time_step_loc;

	VBObject object;
};

