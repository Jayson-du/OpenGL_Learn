#pragma once
#include "DrawInterface.h"
#include "vbm.h"
class Ch10ViewporrArray :
	public IDrawInterface
{
public:
	Ch10ViewporrArray();
	~Ch10ViewporrArray();

	virtual void Init() override;

	virtual void Display() override;

	virtual void OnReshape(int width, int height) override;

private:
	GLuint prog;
	GLuint vao;
	GLuint vbo;
	VBObject object;

	GLint model_matrix_pos;
	GLint projection_matrix_pos;
};

