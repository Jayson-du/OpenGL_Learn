#include "vutils.h"

void vglAttachShaderSource(GLuint prog, GLenum type, const char * source)
{
	GLuint sh;
	sh = glCreateShader(type);
	glShaderSource(sh, 1, &source, nullptr);
	glCompileShader(sh);
	char buffer[4096];
	glGetShaderInfoLog(sh, sizeof(buffer), nullptr, buffer);
	glAttachShader(prog, sh);
	glDeleteShader(sh);
}