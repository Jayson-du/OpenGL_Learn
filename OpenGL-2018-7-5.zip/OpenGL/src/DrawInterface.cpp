#include "DrawInterface.h"
#include <string>
//#undef _DEBUG
void APIENTRY DebugOutputCallback(GLenum source,
	GLenum type,
	GLuint id,
	GLenum severity,
	GLsizei length,
	const GLchar* message,
	GLvoid* userParam)
{
	OutputDebugStringA(message);
	OutputDebugStringA("n");
}

void IDrawInterface::OnReshape(int width, int height)
{
	glViewport(0, 0, width, height);
	aspect = float(height) / float(width);
	current_width = width;
	current_height = height;
}

IDrawInterface* IDrawInterface::Instance = nullptr;
typedef BOOL(APIENTRY *PFNWGLSWAPINTERVALFARPROC)(int);
PFNWGLSWAPINTERVALFARPROC wglSwapIntervalEXT = 0;
void IDrawInterface::Initialise()
{
	int one = 1;
	char * name = "name";

#ifdef _DEBUG
	glutInitContextFlags(GLUT_DEBUG);
#endif
	glutInitContextProfile(GLUT_CORE_PROFILE);
	glutInitContextVersion(4, 3);

	glutInitWindowSize(1024, 768);
	glutInitWindowPosition(800, 210);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
	glutInit(&one, &name);

	glutCreateWindow(title ? title : "OpenGL Application");
	glutDisplayFunc(DisplayFunc);
	glutReshapeFunc(ReshapeFunc);
	glutKeyboardFunc(Keyboard);
	// �رմ�ֱͬ��
	wglSwapIntervalEXT = (PFNWGLSWAPINTERVALFARPROC)wglGetProcAddress("wglSwapIntervalEXT");
	//wglSwapIntervalEXT(1);//�򿪴�ֱ�ֲ�������֡��
	wglSwapIntervalEXT(0);//�رմ�ֱ�ֲ�����ַ����Կ�����Ⱦ����

	glewInit();

#ifdef _DEBUG
	if (glDebugMessageCallbackARB != NULL)
		glDebugMessageCallbackARB((GLDEBUGPROCARB)DebugOutputCallback, (void*)this);
#endif

	Init();
}

void IDrawInterface::MainLoop()
{
	for (;;)                                                \
		glutMainLoopEvent();
}

IDrawInterface::IDrawInterface()
{
	aspect = 1;
	title = nullptr;
	if (Instance != nullptr)
	{
		printf("Fatal Error : ���ʵ����");
		throw std::logic_error("Fatal Error : ���ʵ����");
	}
	Instance = this;
}

void IDrawInterface::DisplayFunc(void)
{
	static int count = GetTickCount();
	static int framenum = 0;
	static int lastFrameNum = 0;
	Instance->Display();
	glutSwapBuffers();
	if (true)
	{
		glutPostRedisplay();
	}
	++framenum;
	if (GetTickCount() - count > 999)
	{
		if (lastFrameNum != 0 && lastFrameNum != framenum)
			printf("frame %d\n", framenum);
		lastFrameNum = framenum;
		framenum = 0;
		count = GetTickCount();
	}
}

void IDrawInterface::ReshapeFunc(int width, int height)
{
	Instance->OnReshape(width, height);
}

void IDrawInterface::Keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 033:  // ASCII Escape Key Code
		exit(EXIT_SUCCESS);
		break;
	case 'm':
	{
		GLenum mode[3] = { GL_FILL ,GL_LINE,GL_POINT };
		static int pmodel = 0;
		pmodel = (pmodel + 1) % 3;
		glPolygonMode(GL_FRONT_AND_BACK, mode[pmodel]);
	}
	break;
	}

	Instance->OnKeyboard(key, x, y);
}
