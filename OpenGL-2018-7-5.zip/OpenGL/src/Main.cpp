#include "Ch01Triangle.h"
#include "Ch03DrawCommands.h"
#include "Ch06PointsSprites.h"
#include "Ch03Instanced.h"
#include "Ch05FeedbackParticle.h"
#include "Ch03Restart.h"
#include "Ch04Gouraud.h"
#include "Ch04ShadowMap.h"
#include "Ch05FrameBufferObject.h"
#include "Ch06CubeMap.h"
#include "Ch06StaticTexture.h"
#include "Ch06VolumeTexture.h"
#include "Ch06TextureWrapping.h"
#include "Ch06Mipmap.h"
#include "Ch06RTT.h"
#include "Ch07LightModel.h"
#include "Ch09TessellationShader.h"
#include "Ch10DrawXfb.h"
#include "Ch10Fur.h"
#include "Ch10ViewporrArray.h"
int main(int argc, char** argv)
{
	IDrawInterface * DrawInterface = nullptr;
	//DrawInterface = new Ch01Triangle();

	//DrawInterface = new Ch03DrawCommands();

	//DrawInterface = new Ch03Instanced;
	//DrawInterface = new Ch05FeedbackParticle;
	//DrawInterface = new Ch03Restart;

	//DrawInterface = new Ch04Gouraud;
	//DrawInterface = new Ch04ShadowMap;

	//DrawInterface = new Ch05FrameBufferObject();

	//DrawInterface = new Ch06CubeMap;
	//DrawInterface = new Ch06StaticTexture();
	//DrawInterface = new Ch06VolumeTexture();
	//DrawInterface = new Ch06TextureWrapping();
	//DrawInterface = new Ch06Mipmap();
	//DrawInterface = new Ch06RTT;
	//DrawInterface = new Ch06PointsSprites();

	//DrawInterface = new Ch07LightModel();

	//DrawInterface = new Ch09TessellationShader();

	//DrawInterface = new Ch10Fur;
	DrawInterface = new Ch10DrawXfb;
	//DrawInterface = new Ch10ViewporrArray;
	DrawInterface->Initialise();
	DrawInterface->MainLoop();
}
