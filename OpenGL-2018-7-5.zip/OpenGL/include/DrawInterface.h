#pragma once
#pragma warning(disable:4005 4312 4244 4520 4018 4267 4800 4996 4482 4101 4002 4102 4101 4838 4305 4996) 

#include <GL/glew.h>
#include <GL/freeglut.h>
#include "vutils.h"
#include "vmath.h"
#include "LoadShaders.h"
using namespace vmath;

#define BUFFER_OFFSET(x)  ((const void*) (x))
class IDrawInterface
{
public: 
	virtual void Init() = 0;
	virtual void Display() = 0;
	virtual void OnKeyboard(unsigned char key, int x, int y ) {}
	virtual void OnReshape(int width,int height);
	static IDrawInterface* Instance;
public:
	void Initialise();
	void MainLoop();
	IDrawInterface();
protected:
	static void DisplayFunc(void);
	static void ReshapeFunc(int width, int height);
	static void Keyboard( unsigned char key, int x, int y );
	float aspect;
	GLint current_width;
	GLint current_height;
	char *title;
};


