#pragma  once
#include <GL/glew.h>
void vglAttachShaderSource(GLuint prog, GLenum type, const char * source);
